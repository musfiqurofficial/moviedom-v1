import React from "react";
import { Container } from "react-bootstrap";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
import { LOGO_PATH, LOGO_WIDTH } from "../../../Api/MovieDom";
import { A } from "../../../style/common/Tag";
import { Logo } from "../../../style/layout/Navbar";
import theme from "../../../style/theme";
import { P } from "../../../style/typography/typography";

const Footer = () => {
  const { site } = useSelector((store) => store.site);
  return null;
  return (
    <footer style={{ background: theme.dark_lt }}>
      <Container className="center justify-content-between py-3 mt-3">
        <A as={NavLink} to="/">
          <Logo
            alt="LOGO"
            src={site?.logo || LOGO_PATH}
            style={{
              maxWidth: (site?.logo_width || LOGO_WIDTH.value) * 0.8,
              width: "100%",
            }}
          />
        </A>
        <P className="text-center mb-0">
          ©2022{" "}
          <A href="###" style={{ color: theme.primary }}>
            BRISK
          </A>{" "}
          . All Rights Reserved. Developed By{" "}
          <A href="###" style={{ color: theme.primary }}>
            BRISK
          </A>
        </P>
      </Container>
    </footer>
  );
};

export default Footer;
