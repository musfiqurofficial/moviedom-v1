const theme = {
    primary: '#E83566',
    secondary: '',
    dark: '#0e0d12',
    dark_lt: '#131722',
    light: '#ffffff',
    text:'#ccc'
};

export default theme;